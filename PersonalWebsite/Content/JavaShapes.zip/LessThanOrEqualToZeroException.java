//Spencer Krug
//Custom exception class
//09/18/2019

public class LessThanOrEqualToZeroException extends RuntimeException{
	//Contructors.
	public LessThanOrEqualToZeroException()
	{
		super("The number you input was less than or equal to 0.");
	}
	
	public LessThanOrEqualToZeroException(String myField, int myNumber)
	{
		super("\n***** you entered " + myNumber + ". " + myField + " must be greater than 0.");
	}
}
