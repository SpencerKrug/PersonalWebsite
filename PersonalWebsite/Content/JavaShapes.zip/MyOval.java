//Spencer Krug
//Oval class
//09/11/2019

import java.awt.Color;
import java.awt.Graphics;

public class MyOval extends Point{
	private boolean filled;
	private int radius;
	private int height;
	
	//Contructors.
	public MyOval()
	{
		super();
		
		this.filled = true;
	}
	
	public MyOval(int newX, int newY, int newRadius)
	{
		super(newX, newY);
		radius = newRadius;
	}
	
	public MyOval(int newX, int newY, int newRadius, int newHeight)
	{
		super(newX, newY);
		radius = newRadius;
		height = newHeight;
	}
	
	//Other methods.
	public DrawFigure drawFigure(int type)
	{
		DrawFigure demo2 = new DrawFigure(type, radius, height);
		return demo2;
	}
	
	//Determines whether this shape is filled or not.
	public boolean isFilled()
	{
		return this.filled;
	}
	
	//Sets this shape to filled or not.
	public void setFilled(boolean filled)
	{
		this.filled = filled;
	}
}
