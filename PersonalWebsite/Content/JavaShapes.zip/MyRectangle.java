//Spencer Krug
//Rectangle class
//09/30/2019

import java.awt.Color;
import java.awt.Graphics;

public class MyRectangle extends Point{
	private boolean filled;
	private int width;
	private int length;
	private int height;
	
	//Contructors.
	public MyRectangle()
	{
		super();
		
		this.filled = true;
	}
	
	public MyRectangle(int newX, int newY, int newWidth, int newLength)
	{
		super(newX, newY);
		width = newWidth;
		length = newLength;
	}
	
	public MyRectangle(int newX, int newY, int newWidth, int newLength, int newHeight)
	{
		super(newX, newY);
		width = newWidth;
		length = newLength;
		height = newHeight;
	}
	
	//Other methods.
	public DrawFigure drawFigure(int type)
	{
		DrawFigure demo2 = new DrawFigure(type, width, length, height);
		return demo2;
	}
	
	//Determines whether this shape is filled or not.
	public boolean isFilled()
	{
		return this.filled;
	}
	
	//Sets this shape to filled or not.
	public void setFilled(boolean filled)
	{
		this.filled = filled;
	}
}
