//Spencer Krug
//Custom exception class
//09/30/2019

import java.awt.Graphics;
import javax.swing.JPanel;

public class DrawFigure extends JPanel{
	int type, length, width, height, radius;
	
	public DrawFigure()
	{
		super();
		type = 5;
	}
	
	public DrawFigure(int type, int width, int length, int height)
	{
		super();
		this.type = type;
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public DrawFigure(int x, int y, int type, int width, int length, int height)
	{
		super();
		this.type = type;
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public DrawFigure(int x, int y, int type, int radius, int height)
	{
		super();
		this.type = type;
		this.radius = radius;
		this.height = height;
	}
	
	public DrawFigure(int type, int radius, int height)
	{
		super();
		this.type = type;
		this.radius = radius;
		this.height = height;
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		if (type == 1)
		{
			g.drawRect(50, 110, width, length);
		}
		
		if (type == 2)
		{
			g.drawOval(50, 110, radius, radius);
		}
		
		if (type == 3)
		{
			g.drawRect(50, 110, width, length);
			g.drawRect(50 + height, 110 + height, width, length);
			
			g.drawLine(50, 110, 50 + height, 110 + height);
			g.drawLine(50 + width, 110, 50 + height + width, 110 + height);
			g.drawLine(50, 110 + length, 50 + height, 110 + height + length);
			g.drawLine(50 + width, 110 + length, 50 + height + width, 110 + height + length);
		}
		
		if (type == 4)
		{
			System.out.println(height);
			g.drawOval(50, 110, radius, radius);
			g.drawOval(50, 110 + height, radius, radius);
			g.drawLine(50, 110 + (radius / 2), 50, (110 + height) + (radius / 2));
			g.drawLine(50 + radius, 110 + (radius / 2), 50 + radius, (110 + height) + (radius / 2));
		}
	}
}
