//Spencer Krug
//GUILab
//09/28/2019

import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
//For Week6Lab
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.InputMismatchException;

public class GUILab implements ActionListener{
	JPanel totalGUI;
	ButtonGroup group;
	JLabel errLabel, titleLabel, radiolabel, widthLabel, heightLabel, radiusLabel, lengthLabel;
	JRadioButton rectangleRadioButton, boxRadioButton, circleRadioButton, cylinderRadioButton;
	JTextField widthTextField, lengthTextField, heightTextField, radiusTextField;
	JPanel radioButtonPanel, widthPanel, lengthPanel, heightPanel, radiusPanel;
	JButton processButton;
	//Debug: System.out.println("Debug");
	
	//For Week6Lab
	static private int width, length, radius, height;
	static private boolean dimensionError;
	
	public static void main(String[] args) {
		createAndShowGui();
	}
	
	public JPanel createContentPane()
	{
		//Main
		JPanel totalGUI = new JPanel();
		totalGUI.setLayout(null);
		
		titleLabel = new JLabel("<html><span style='font-size:20px'>"+"Spencer Krug"+"</span></html>");
		titleLabel.setLocation(175, 0);
		titleLabel.setSize(500, 250);
		totalGUI.add(titleLabel);
		
	    processButton = new JButton("Draw");
	    processButton.setLocation(175, 375);
	    processButton.setSize(150, 50);
	    processButton.addActionListener(this);
		totalGUI.add(processButton);
		
		errLabel = new JLabel("Dimension Error >>>> Can Not Render Drawing!");
		errLabel.setSize(300, 30);
		errLabel.setLocation(25, 0);
		errLabel.setOpaque(true);
		errLabel.setBackground(Color.RED);
		errLabel.setVisible(false);
		totalGUI.add(errLabel);
		
		//Radio Buttons
		radioButtonPanel = new JPanel();
		//radioButtonPanel.setBackground(Color.RED);
		radioButtonPanel.setLayout(null);
		radioButtonPanel.setSize(100, 300);
		radioButtonPanel.setLocation(0, 150);
		totalGUI.add(radioButtonPanel);
		
		radiolabel = new JLabel("Select Figure:");
		radiolabel.setLocation(0, 0);
		radiolabel.setSize(120,  30);
		radiolabel.setHorizontalAlignment(0);
		radiolabel.setForeground(Color.RED);
		radioButtonPanel.add(radiolabel);
		
		rectangleRadioButton = new JRadioButton("Rectangle");
		rectangleRadioButton.setSize(150, 20);
		rectangleRadioButton.setLocation(0, 30);
		rectangleRadioButton.addActionListener(this);
		radioButtonPanel.add(rectangleRadioButton);
		
		boxRadioButton = new JRadioButton("Box");
		boxRadioButton.setSize(150, 20);
		boxRadioButton.setLocation(0, 60);
		boxRadioButton.addActionListener(this);
		radioButtonPanel.add(boxRadioButton);
		
		circleRadioButton = new JRadioButton("Circle");
		circleRadioButton.setSize(150, 20);
		circleRadioButton.setLocation(0, 90);
		circleRadioButton.addActionListener(this);
		radioButtonPanel.add(circleRadioButton);
		
		cylinderRadioButton = new JRadioButton("Cylinder");
		cylinderRadioButton.setSize(150, 20);
		cylinderRadioButton.setLocation(0, 120);
		cylinderRadioButton.addActionListener(this);
		radioButtonPanel.add(cylinderRadioButton);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rectangleRadioButton);
		group.add(boxRadioButton);
		group.add(circleRadioButton);
		group.add(cylinderRadioButton);
		
		//Width
		widthPanel = new JPanel();
		//widthPanel.setBackground(Color.ORANGE);
		widthPanel.setLayout(null);
		widthPanel.setSize(150, 100);
		widthPanel.setLocation(100, 150);
		//totalGUI.add(widthPanel);
		
		widthLabel = new JLabel("Width:");
		widthLabel.setLocation(0, 0);
		widthLabel.setSize(120,  30);
		widthLabel.setHorizontalAlignment(0);
		widthLabel.setForeground(Color.RED);
		widthPanel.add(widthLabel);
		
	    widthTextField = new JTextField("Width");
	    widthTextField.setLocation(0, 25);
	    widthTextField.setSize(120, 30);
	    widthPanel.add(widthTextField);
	    
		//Length
		lengthPanel = new JPanel();
		//lengthPanel.setBackground(Color.YELLOW);
		lengthPanel.setLayout(null);
		lengthPanel.setSize(150, 100);
		lengthPanel.setLocation(250, 150);
		//totalGUI.add(lengthPanel);
		
		lengthLabel = new JLabel("Length:");
		lengthLabel.setLocation(0, 0);
		lengthLabel.setSize(120,  30);
		lengthLabel.setHorizontalAlignment(0);
		lengthLabel.setForeground(Color.RED);
		lengthPanel.add(lengthLabel);
		
	    lengthTextField = new JTextField("Length");
	    lengthTextField.setLocation(0, 25);
	    lengthTextField.setSize(120, 30);
	    lengthPanel.add(lengthTextField);
		
		//Height
		heightPanel = new JPanel();
		//heightPanel.setBackground(Color.BLUE);
		heightPanel.setLayout(null);
		heightPanel.setSize(150, 100);
		heightPanel.setLocation(100, 250);
		//totalGUI.add(heightPanel);
		
		heightLabel = new JLabel("Height:");
		heightLabel.setLocation(0, 0);
		heightLabel.setSize(120,  30);
		heightLabel.setHorizontalAlignment(0);
		heightLabel.setForeground(Color.RED);
		heightPanel.add(heightLabel);
		
	    heightTextField = new JTextField("Height");
	    heightTextField.setLocation(0, 25);
	    heightTextField.setSize(120, 30);
	    heightPanel.add(heightTextField);
	    
		//Radius
		radiusPanel = new JPanel();
		//radiusPanel.setBackground(Color.BLACK);
		radiusPanel.setLayout(null);
		radiusPanel.setSize(150, 100);
		radiusPanel.setLocation(250, 250);
		//totalGUI.add(radiusPanel);
		
		radiusLabel = new JLabel("Radius:");
		radiusLabel.setLocation(0, 0);
		radiusLabel.setSize(120,  30);
		radiusLabel.setHorizontalAlignment(0);
		radiusLabel.setForeground(Color.RED);
		radiusPanel.add(radiusLabel);
		
	    radiusTextField = new JTextField("Radius");
	    radiusTextField.setLocation(0, 25);
	    radiusTextField.setSize(120, 30);
	    radiusPanel.add(radiusTextField);
	    
	    //Hidding panels until radio a button is clicked.
	    lengthPanel.setVisible(false);
		widthPanel.setVisible(false);
		heightPanel.setVisible(false);
		radiusPanel.setVisible(false);
		processButton.setVisible(false);
		
		//Adding panels to main panel.
		totalGUI.add(lengthPanel);
		totalGUI.add(widthPanel);
		totalGUI.add(heightPanel);
		totalGUI.add(radiusPanel);
	    
		return totalGUI;
	}
	
	private static void createAndShowGui()
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame();
		
		GUILab demo = new GUILab();
		frame.setContentPane(demo.createContentPane());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		dimensionError = true;
		errLabel.setVisible(false);
		int type = 5;
		
		if (rectangleRadioButton.isSelected())
		{
			lengthPanel.setVisible(true);
			widthPanel.setVisible(true);
			heightPanel.setVisible(false);
			radiusPanel.setVisible(false);
			processButton.setVisible(true);
			//widthTextField.setBackground(Color.WHITE);
			//lengthTextField.setBackground(Color.WHITE);
		}
		else if (boxRadioButton.isSelected())
		{
			lengthPanel.setVisible(true);
			widthPanel.setVisible(true);
			heightPanel.setVisible(true);
			radiusPanel.setVisible(false);
			processButton.setVisible(true);
			//widthTextField.setBackground(Color.WHITE);
			//lengthTextField.setBackground(Color.WHITE);
			//heightTextField.setBackground(Color.WHITE);
		}
		else if (circleRadioButton.isSelected())
		{
			lengthPanel.setVisible(false);
			widthPanel.setVisible(false);
			heightPanel.setVisible(false);
			radiusPanel.setVisible(true);
			processButton.setVisible(true);
			//radiusPanel.setBackground(Color.WHITE);
		}
		else if (cylinderRadioButton.isSelected())
		{
			lengthPanel.setVisible(false);
			widthPanel.setVisible(false);
			heightPanel.setVisible(true);
			radiusPanel.setVisible(true);
			processButton.setVisible(true);
			//radiusPanel.setBackground(Color.WHITE);
			//heightPanel.setBackground(Color.WHITE);
		}
		
		if (e.getSource() == processButton)
		{
			if (rectangleRadioButton.isSelected())
			{
				type = 1;
				dimensionError = false;
				try 
				{
					width = Integer.parseInt(widthTextField.getText());
					lessThanOrEqualToZeroException(" width ", width);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					widthTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					widthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					widthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				try 
				{
					length = Integer.parseInt(lengthTextField.getText());
					lessThanOrEqualToZeroException(" length ", length);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					lengthTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					lengthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					lengthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				if (!dimensionError)
				{
					createAndShowFigure(type);
				}
				else 
				{
					errLabel.setVisible(true);
				}
			}
			else if (circleRadioButton.isSelected())
			{
				type = 2;
				dimensionError = false;
				try 
				{
					radius = Integer.parseInt(radiusTextField.getText());
					lessThanOrEqualToZeroException(" radius ", radius);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					radiusTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					radiusTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					radiusTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				if (!dimensionError)
				{
					createAndShowFigure(type);
				}
				else 
				{
					errLabel.setVisible(true);
				}
			}
			else if (boxRadioButton.isSelected())
			{
				type = 3;
				dimensionError = false;
				try 
				{
					width = Integer.parseInt(widthTextField.getText());
					lessThanOrEqualToZeroException(" width ", width);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					widthTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					widthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					widthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				try 
				{
					length = Integer.parseInt(lengthTextField.getText());
					lessThanOrEqualToZeroException(" length ", length);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					lengthTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					lengthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					lengthTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				try 
				{
					height = Integer.parseInt(heightTextField.getText());
					lessThanOrEqualToZeroException(" height ", height);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					heightTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					heightTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					heightTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				if (!dimensionError)
				{
					createAndShowFigure(type);
				}
				else 
				{
					errLabel.setVisible(true);
				}
			}
			else if (cylinderRadioButton.isSelected())
			{
				type = 4;
				dimensionError = false;
				try 
				{
					radius = Integer.parseInt(radiusTextField.getText());
					lessThanOrEqualToZeroException(" radius ", radius);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					radiusTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					radiusTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					radiusTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				try 
				{
					height = Integer.parseInt(heightTextField.getText());
					lessThanOrEqualToZeroException(" height ", height);
				} 
				catch (LessThanOrEqualToZeroException ex) 
				{
					heightTextField.setBackground(Color.YELLOW);
					dimensionError = true;
					System.out.println(ex);
				}
				catch(InputMismatchException ex)
				{
					heightTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				catch(NumberFormatException ex)
				{
					heightTextField.setBackground(Color.RED);
					dimensionError = true;
				}
				
				if (!dimensionError)
				{
					createAndShowFigure(type);
				}
				else 
				{
					errLabel.setVisible(true);
				}
			}
		}
	}
	
	private static void createAndShowFigure(int type)
	{
		JFrame frame2 = new JFrame("Lab 06 GUI 02 Parital");
		
		if (type == 1)
		{
			MyRectangle demo = new MyRectangle(100, 200, width, length);
			frame2.setContentPane(demo.drawFigure(1));
		}
		else if (type == 2)
		{
			MyOval demo = new MyOval(100, 200, radius);
			frame2.setContentPane(demo.drawFigure(2));
		}
		else if (type == 3)
		{
			MyRectangle demo = new MyRectangle(100, 200, width, length, height);
			frame2.setContentPane(demo.drawFigure(3));
		}
		else if (type == 4)
		{
			MyOval demo = new MyOval(100, 200, radius, height);
			frame2.setContentPane(demo.drawFigure(4));
		}
		
		//frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.setSize(700, 700);
		frame2.setLocationRelativeTo(null);
		frame2.setVisible(true);
	}
	
	public static void lessThanOrEqualToZeroException(String myField, int myNumber) throws LessThanOrEqualToZeroException
	{
		if (myNumber <= 0)
		{
			throw new LessThanOrEqualToZeroException(myField, myNumber);
		}
	}

}
