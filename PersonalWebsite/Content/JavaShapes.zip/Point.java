//Spencer Krug
//Point Class
//09/30/2019

import java.awt.Color;
import java.awt.Graphics;
public class Point {
	private int xCord;
	private int yCord;
	
	public Point()
	{
		xCord = 0;
		yCord = 0;
	}
	
	public Point(int x, int y)
	{
		xCord = x;
		yCord = y;
	}
	
	public int getX()
	{
		return xCord;
	}
	
	public int getY()
	{
		return yCord;
	}
	
	public void setX(int x)
	{
		this.xCord = x;
	}
	
	public void setY(int y)
	{
		this.yCord = y;
	}
	
	public String toString()
	{
		return "The X cordinate is " + xCord + "." +
				" The Y cordinate is " + yCord + ".";
	}
}